<?php



namespace TemplateCYC;

/**
 * controlador de vista
 */
class ControllerTemplateCYC {
	
	//retorna todos las licitaciones
	public function all(\TemplateCYC\ModelTemplateCYC $model){
		return $model;
	}

}