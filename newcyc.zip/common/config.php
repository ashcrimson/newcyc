<?php

/**
 * 
 */
class ClassName{
	
	function __construct()
	{
		//# code...
	}
}