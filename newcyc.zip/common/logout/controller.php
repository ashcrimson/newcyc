<?php



namespace LogoutCYC;

/**
 * controlador de vista
 */
class ControllerLogoutCYC {
	
	//retorna todos las licitaciones
	public function all(\LogoutCYC\ModelLogoutCYC $model){
		return $model;
	}

}