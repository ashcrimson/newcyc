<?php



namespace Home;

/**
 * pagina 404, modelo vacio, a no ser que se necesite algun dato en el futuro
 */
class ModelHome{
	
	function __construct(){
		//
	}
}