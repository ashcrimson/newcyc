<?php



namespace NotFound;

/**
 * pagina 404, modelo vacio, a no ser que se necesite algun dato en el futuro
 */
class ModelNotFound{
	
	function __construct(){
		//
	}
}